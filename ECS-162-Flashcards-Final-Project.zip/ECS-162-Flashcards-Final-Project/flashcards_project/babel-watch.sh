#!/usr/bin/sh
npx babel user --presets react-app/prod --extensions ".jsx" user --watch --out-dir user
